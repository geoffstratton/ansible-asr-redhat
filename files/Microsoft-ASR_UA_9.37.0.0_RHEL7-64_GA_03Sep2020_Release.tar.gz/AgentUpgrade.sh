#!/bin/sh

VX_VERSION_FILE="/usr/local/.vx_version"
UPGRADE_LOG_FILE="/var/log/upgrader.log"
SCRIPT_DIR=$(readlink -f `dirname "$0"`)
CUR_DIR=`pwd`
INSTALLATION_DIR=$(grep ^INSTALLATION_DIR $VX_VERSION_FILE | cut -d"=" -f2 | tr -d " ")

trace_log_message() {
    DATE_TIME=`date '+%Y/%m/%d %H:%M:%S'`
    echo -e "$@"
    echo "${DATE_TIME} : $@ " >> ${UPGRADE_LOG_FILE} 2>&1
}

exit_with_retcode() {
    #Moving to original directory
    cd $CUR_DIR

    #TODO Upload upgrader and AzureRcmCLi log.
    exit $1
}

upgrade_mobility_service() {
    INSTALL_ERROR_JSON="$SCRIPT_DIR/installerextendederrors.json"
    $SCRIPT_DIR/install -r MS -v VmWare -q -a Upgrade -c CSPrime -l $SCRIPT_DIR/stdout.txt \
        -e $INSTALL_ERROR_JSON -j $SCRIPT_DIR/installerjson.json
    ret_val=$?
    cat $SCRIPT_DIR/stdout.txt >> ${UPGRADE_LOG_FILE}
    return $ret_val
}

register_source_agent() {
    ${INSTALLATION_DIR}/bin/AzureRcmCli --registersourceagent >> $UPGRADE_LOG_FILE 2>&1
    return $?
}

upgrade_action() {
    upgrade_mobility_service
    upgrade_ret_val=$?

    if [ $upgrade_ret_val -ne 0 -a $upgrade_ret_val -ne 98 \
        -a $upgrade_ret_val -ne 209 ]; then
        trace_log_message "Upgrade agent failed with return value : $upgrade_ret_val"
        return $upgrade_ret_val
    fi
    register_source_agent
    reg_source_exit_code=$?
    trace_log_message ""
    if [ $reg_source_exit_code -eq 0 ]; then
        trace_log_message "registersourceagent operation has succeeded."
    else
        trace_log_message "registersourceagent failed with exit code - $reg_source_exit_code"
    fi
    return $reg_source_exit_code
}

complete_job_to_rcm() {
    ${INSTALLATION_DIR}/bin/AzureRcmCli --completeagentupgrade --agentupgradeexitcode \
        "$upgrade_action_return_value" --agentupgradejobdetails "$JOB_FILE_PATH" --errorfilepath \
        "$INSTALL_ERROR_JSON" >> $UPGRADE_LOG_FILE 2>&1
    return $?
}

post_action() {
    complete_job_to_rcm
    post_exit_code=$?
    if [ $post_exit_code -eq 0 ]; then
        trace_log_message "Post actions completed successfully"
    else
        trace_log_message "Post actions failed"
    fi
    return $post_exit_code
}

delete_job_file() {
    rm -f $JOB_FILE_PATH
}

main() {
    while getopts :j:  opt
    do
        case $opt in
        j)  JOB_FILE_PATH="$OPTARG"
        ;;
        *)  trace_log_message "Incorrect usage"
            exit_with_retcode 1
        ;;
        esac
    done

    if [ -z "$JOB_FILE_PATH" ]; then
        trace_log_message "Job File not provided"
        exit_with_retcode 1
    fi
    if [ ! -f "$JOB_FILE_PATH" ]; then
        trace_log_message "File path: $JOB_FILE_PATH doesn't exist"
        exit_with_retcode 1
    fi
    #installer needs to be invoked from the same directory
    cd $SCRIPT_DIR

    upgrade_action
    upgrade_action_return_value=$?
    post_action || exit_with_retcode $?
    delete_job_file
    exit_with_retcode 0
}

main "$@"
