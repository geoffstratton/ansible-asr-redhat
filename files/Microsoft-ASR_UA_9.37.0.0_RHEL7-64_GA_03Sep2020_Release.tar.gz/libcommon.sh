log_string()
{
    # $1 -> the json error file name
    # $2 -> string to be appended
    head -q -n -2 $1 > /tmp/out.json
    head -q -c -1  /tmp/out.json > $1
    echo -e -n $2 >> $1
    echo -e "\n\t]\n}" >> $1
    rm -rf /tmp/out.json
}

# This function will log the error to the output JSON file
# The format of JSON file is
#
# {
#    "Errors":
#    [
#        {
#            "Error_name":"err1",
#            "Error_params":{"l":"m","p":"q","x":"z"},
#            "Default_message": "error1 occured"
#        },
#        {
#            "Error_name":"err2",
#            "Error_params":{"l":"m","p":"q","x":"z"},
#            "Default_message": "error2 occured"
#        },
#        {
#            "Error_name":"err3",
#            "Error_params":{"l":"m","p":"q","x":"z"},
#            "Default_message": "error3 occured"
#        }
#    ]
# }

log_to_json_errors_file()
{
    local json_errors_file=$1
    error_code=$2
    error_message=$3
    nr_args=$#

    if [ ! -f $json_errors_file ]; then
        echo -e "{\n\t\"Errors\":\n\t[\n\t]\n}" >> $json_errors_file
    else
        log_string $json_errors_file ","
    fi
    log_string  $json_errors_file "\n\t\t{"
    log_string  $json_errors_file "\n\t\t\t\"error_name\":\"${error_code}\","
    
    nr_args=`expr ${nr_args} - 3`
    shift; shift; shift
    nr_params=0
    str=""
    while [ ${nr_args} -gt "0" ]
    do
        if [ ${nr_params} -eq "0" ]; then
            str="$str\t\t\t\"error_params\":{"
        fi
        if [ ${nr_params} -gt "0" ]; then
            str="$str,"
        fi
            str="$str\"$1\":\""
        shift
            str="$str$1\""
        shift
        nr_params=`expr ${nr_params} + 1`
        nr_args=`expr ${nr_args} - 2`
    done

    if [ ${nr_params} -gt "0" ]; then
        str="\n$str},"
        log_string $json_errors_file $str
    fi

    log_string $json_errors_file "\n\t\t\t\"default_message\":\"${error_message}\"\n\t\t}"

}

